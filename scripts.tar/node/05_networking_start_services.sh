#!/usr/bin/env bash

systemctl start openvswitch
systemctl enable openvswitch
