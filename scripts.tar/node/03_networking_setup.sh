#!/usr/bin/env bash

yum install -y openstack-neutron-openvswitch
yum install -y openstack-neutron-ml2
yum install -y openstack-selinux
