#!/usr/bin/env bash

export nova_conf=/etc/nova/nova.conf
export nova_api=/etc/nova/api-paste.ini
