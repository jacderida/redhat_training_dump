#!/usr/bin/env bash

source keystonerc_myuser
cinder create --display-name vol2 2
