#!/usr/bin/env bash

yum install -y openvswitch
yum install -y openstack-neutron
yum install -y openstack-neutron-ml2
yum install -y openstack-neutron-openvswitch
