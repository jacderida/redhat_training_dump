#!/usr/bin/env bash

runuser -s /bin/sh -c "heat-manage db_sync"
